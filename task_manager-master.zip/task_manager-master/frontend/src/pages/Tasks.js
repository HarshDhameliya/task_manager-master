import { Box } from '@mui/material'
import AllTasks from '../components/AllTasks'

const Tasks = () => {
  return (
    <Box>
      <AllTasks />
    </Box>
  )
}

export default Tasks